import os
import streamlit as st
import subprocess
import json
from pathlib import Path
from llama_index import StorageContext, load_index_from_storage
from docx import Document
from datetime import datetime

from mistral_query_engine import get_local_engine
from config import COURSE_PATH, CHAT_MEMORY_DIR, CONCEPT_MAP_DIR, EMBEDDING_DIR

os.makedirs(CHAT_MEMORY_DIR, exist_ok=True)

@st.cache_resource
def load_course_index(course_name):
    index_path = os.path.join(COURSE_PATH, course_name, "index")
    storage_context = StorageContext.from_defaults(persist_dir=index_path)
    return load_index_from_storage(storage_context)

def load_memory(course_name):
    path = os.path.join(CHAT_MEMORY_DIR, f"{course_name}.json")
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    return []

def save_memory(course_name, chat_log):
    path = os.path.join(CHAT_MEMORY_DIR, f"{course_name}.json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(chat_log, f, indent=2)

def export_chat_log(chat_log):
    doc = Document()
    doc.add_heading("Course Q&A Chat Log", 0)
    for q, a in chat_log:
        doc.add_paragraph(f"Q: {q}", style='List Bullet')
        doc.add_paragraph(f"A: {a}", style='List Bullet')
    filename = f"chat_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.docx"
    doc.save(filename)
    return filename

def list_courses():
    return [name for name in os.listdir(COURSE_PATH)
            if os.path.isdir(os.path.join(COURSE_PATH, name, "index"))]

st.set_page_config(page_title="Course AI + Visual Tools", page_icon="favicon.png", layout="wide")
st.title("📚 Multi-Course AI Assistant")

course_list = list_courses()
selected_course = st.selectbox("Select Course", course_list)

use_local_llm = st.checkbox("🔁 Use Local Mistral Instead of OpenAI")
enable_memory = st.checkbox("📌 Enable Chat Memory")

index = load_course_index(selected_course)
query_engine = get_local_engine(index) if use_local_llm else index.as_query_engine()

if enable_memory:
    st.session_state.chat_log = load_memory(selected_course)
else:
    st.session_state.chat_log = []

query = st.text_input("Ask a question:")

if query:
    response = query_engine.query(query)
    st.session_state.chat_log.append((query, str(response)))
    st.markdown(f"**Answer:** {response}")
    if enable_memory:
        save_memory(selected_course, st.session_state.chat_log)

if st.button("Export Chat Log"):
    filename = export_chat_log(st.session_state.chat_log)
    with open(filename, "rb") as f:
        st.download_button("Download Chat Log", f, file_name=filename)

st.markdown("---")
st.subheader("🧠 Visual Insights")

map_path = Path(CONCEPT_MAP_DIR) / f"{selected_course}_concept_map.png"
embed_path = Path(EMBEDDING_DIR) / f"{selected_course}_embedding.png"

if map_path.exists():
    st.image(str(map_path), caption="Syllabus Concept Map", use_column_width=True)
else:
    st.warning("No concept map available. Run `syllabus_concept_map.py` first.")

if embed_path.exists():
    st.image(str(embed_path), caption="Topic Embedding Map", use_column_width=True)
else:
    st.warning("No embedding map available. Run `visual_embedding_map.py` first.")