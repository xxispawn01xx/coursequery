# 🧠 Real Estate AI Stack – Final Version

## Setup
1. Run `install.bat`
2. Drop your .gguf model into `models/gguf/`
3. Run `python start_app.py`

## Local LLM (Mistral)
- Download: `mistral-7b-instruct-v0.1.Q4_K_M.gguf`
- Place in: `models/gguf/`

## Folder Structure
- `courses/`: Course folders
- `transcripts/`: Audio transcriptions
- `chat_memory/`: Conversation logs
- `concept_maps/`, `embedding_maps/`: Visual insights