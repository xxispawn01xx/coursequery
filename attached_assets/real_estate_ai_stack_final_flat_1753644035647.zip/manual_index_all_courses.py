import os
from llama_index import VectorStoreIndex, SimpleDirectoryReader

COURSE_ROOT = "courses"

for course in os.listdir(COURSE_ROOT):
    course_dir = os.path.join(COURSE_ROOT, course)
    if not os.path.isdir(course_dir):
        continue
    try:
        print(f"📚 Indexing course: {course}")
        docs = SimpleDirectoryReader(course_dir).load_data()
        index = VectorStoreIndex.from_documents(docs)
        index.storage_context.persist(persist_dir=os.path.join(course_dir, "index"))
    except Exception as e:
        print(f"⚠️ Failed to index {course}: {e}")