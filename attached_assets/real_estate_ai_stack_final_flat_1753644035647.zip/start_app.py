import subprocess
import os

# Step 1: Check if local model exists
model_path = "models/gguf"
if not os.path.exists(model_path) or not any(f.endswith(".gguf") for f in os.listdir(model_path)):
    print("❌ Model folder not found. Please run update_mistral_model.py")

# Step 2: Re-index courses
print("🔍 Re-indexing courses...")
subprocess.call(["python", "manual_index_all_courses.py"])

# Step 3: Launch Streamlit
print("🚀 Launching Streamlit app...")
subprocess.call(["streamlit", "run", "app_multi_course.py"])